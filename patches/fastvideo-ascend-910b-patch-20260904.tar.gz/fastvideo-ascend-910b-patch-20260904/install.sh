#!/usr/bin/env bash
set -euo pipefail

PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="${1:-$(pwd)}"
TARGET_ROOT="$(cd "${TARGET_ROOT}" && pwd)"
UPSTREAM_COMMIT=7bb76b5ec99807a66aa3047b901f15019abe0f00

sha256_file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  else
    shasum -a 256 "$1" | awk '{print $1}'
  fi
}

require_source_tree() {
  test -f "${TARGET_ROOT}/pyproject.toml" || {
    echo "Not a FastVideo source tree: ${TARGET_ROOT}" >&2
    exit 2
  }
  grep -q 'name = "fastvideo"' "${TARGET_ROOT}/pyproject.toml" || {
    echo "Unexpected pyproject.toml in ${TARGET_ROOT}" >&2
    exit 2
  }
}

is_previous_patch_file() {
  local relative="$1" actual="$2"
  case "${relative}:${actual}" in
    fastvideo/pipelines/preprocess/preprocess_minimax_h3_overfit.py:24476949ecaeca073e08c2bcba2e7a5c3a9ea38a5a970d61252bfb9c8b78f7d8 | \
    docs/getting_started/ascend_910b_h3_training.md:066e8d74754440fbb61df1f8d6c5a9474071fc46b5900b1785a5fe509a87d3cb | \
    docs/getting_started/ascend_910b_h3_training.md:c636066b71b5c6db3065d8e20348ddeca055b26a1fac97035a55aea946f03624 | \
    docs/getting_started/ascend_910b_h3_training.md:fc6ac0f867d647977f10f3f7b93ffe2193d9fe996d88e0716506b2ca1d26e8cd | \
    docs/getting_started/ascend_910b_h3_training.md:300fcb1fd2af5cc92d2a5f0f21f8ebb58e7ba81a3769833708f2b2adca2d3d35 | \
    docs/getting_started/ascend_910b_h3_training.md:376801dbb40acd99ad7a0a66d268a914f286f393e9648d052013a81e009fe55c | \
    docs/getting_started/ascend_910b_h3_training.md:2bfc330acacdb3a5a98fb5ba1da60e12d263efc16a0454fe1f791ac7f3801fdb | \
    docs/getting_started/ascend_910b_h3_training.md:b46bea4ac51a7ca10d8f89277b507851319162864d44a335a0242ffdf69b6b74 | \
    docker/Dockerfile.ascend:7f94639e5716289b952f7c20e79622712f169e60e76d3d03151724400b946dfb | \
    examples/train/configs/ascend/minimax_h3_t2va_sft_smoke.yaml:83ff00417898c024a44265376fc841a4bde818c6b4de5f7e304057d78e3bff90 | \
    examples/train/configs/ascend/minimax_h3_t2va_sft_smoke.yaml:51b24a7c5d21cc3c7eb5e17be5029b9dddc1c08c017225e4ee53b1eb34815623 | \
    examples/train/configs/ascend/minimax_h3_t2va_sft_smoke.yaml:edecc443c2ec5971118521b7265c5808353e0700203b711f7d899d2817440841 | \
    examples/train/configs/ascend/minimax_h3_t2va_dmd2_4step_smoke.yaml:75ed1fefedba7623a3b1347d9311fccc079d172fec21fea08ee4e008a5bcabc8 | \
    examples/train/prepare_minimax_h3_ascend.sh:07fde333a1d22227d13747b262f5d8dc5faf5c6fe85f9db62e9c974e0a0de8de | \
    examples/train/prepare_minimax_h3_ascend.sh:c08ef4ca99cbed27151f13499ad5149fc7bd2701a394bfa8d55296c76e84ba8d | \
    examples/train/prepare_minimax_h3_ascend.sh:a909b14aa4233c58eed9d5e1280abbb6913e294f6012783dcbe677cb55fc1a73 | \
    examples/train/prepare_minimax_h3_ascend.sh:5eefaaf1d21dc56023e3edb7e07d264491f41f974926c243a679c4a2cacb7318 | \
    examples/train/prepare_minimax_h3_ascend.sh:a1bf6934162441300b71c7a3bd2fc113b6245188e220b4a230cb921e2e63dd42 | \
    fastvideo/train/methods/distribution_matching/minimax_h3_dmd2.py:85c1c88ab8d78dde847810a344dba9f62d093a49a227971aa9781233e4a074e5 | \
    requirements/ascend-training.txt:cf01e2819c9bb4b7bb999de6026850b4a8e40dbc8ce5ed2836bb725b0dbd85b2 | \
    requirements/ascend-training.txt:cda0d5cb64caccd8d11d46aa295f39b07beb8fa3bfe906e9c2a7027d213d2b72 | \
    requirements/ascend-training.txt:ec35bab34be444a69aa793a1165c06d3ad8fd431d9006851bc0285d33874219a | \
    scripts/install_ascend_dependencies.sh:97a2297c8447f9073881e0bcc71d0b84bfa983076b2a05296be053765bd95632 | \
    scripts/install_ascend_dependencies.sh:080d4a4f5bb0fffe8ae3f2fa16eec88359d6786ed2502777d54fb863342f52d2 | \
    scripts/install_ascend_dependencies.sh:caeb47fec7d380193c8fa802b9658dab23fc68f6827d6d9a9d264800e6fa01ad)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

validate_bundle() {
  local expected relative source actual
  while IFS=$'\t' read -r _ expected relative; do
    source="${PATCH_ROOT}/payload/replacements/${relative}"
    test -f "${source}" || { echo "Missing replacement payload: ${relative}" >&2; exit 3; }
    actual="$(sha256_file "${source}")"
    test "${actual}" = "${expected}" || { echo "Corrupt replacement payload: ${relative}" >&2; exit 3; }
  done < "${PATCH_ROOT}/modified.tsv"

  while IFS=$'\t' read -r expected relative; do
    source="${PATCH_ROOT}/payload/additions/${relative}"
    test -f "${source}" || { echo "Missing addition payload: ${relative}" >&2; exit 3; }
    actual="$(sha256_file "${source}")"
    test "${actual}" = "${expected}" || { echo "Corrupt addition payload: ${relative}" >&2; exit 3; }
  done < "${PATCH_ROOT}/added.tsv"
}

validate_target() {
  local upstream expected relative target actual
  while IFS=$'\t' read -r upstream expected relative; do
    target="${TARGET_ROOT}/${relative}"
    test -f "${target}" || { echo "Missing upstream file: ${relative}" >&2; exit 4; }
    actual="$(sha256_file "${target}")"
    if test "${actual}" != "${upstream}" && test "${actual}" != "${expected}" && \
      ! is_previous_patch_file "${relative}" "${actual}"; then
      echo "Source version mismatch: ${relative}" >&2
      echo "Expected upstream FastVideo commit ${UPSTREAM_COMMIT}" >&2
      exit 4
    fi
  done < "${PATCH_ROOT}/modified.tsv"

  while IFS=$'\t' read -r expected relative; do
    target="${TARGET_ROOT}/${relative}"
    if test -e "${target}"; then
      actual="$(sha256_file "${target}")"
      if test "${actual}" != "${expected}" && ! is_previous_patch_file "${relative}" "${actual}"; then
        echo "Existing addition differs: ${relative}" >&2
        exit 4
      fi
    fi
  done < "${PATCH_ROOT}/added.tsv"
}

replace_with_sed() {
  local target="$1" replacement="$2" temporary
  temporary="/tmp/fastvideo-ascend-replacement.$$.tmp"
  cp "${replacement}" "${temporary}"
  if sed --version >/dev/null 2>&1; then
    sed -i -e "1r ${temporary}" -e '1,$d' "${target}"
  else
    sed -i '' -e "1r ${temporary}" -e '1,$d' "${target}"
  fi
  rm -f "${temporary}"
}

apply_replacements() {
  local upstream expected relative target actual
  while IFS=$'\t' read -r upstream expected relative; do
    target="${TARGET_ROOT}/${relative}"
    actual="$(sha256_file "${target}")"
    if test "${actual}" != "${expected}"; then
      replace_with_sed "${target}" "${PATCH_ROOT}/payload/replacements/${relative}"
      echo "sed -i: ${relative}"
    else
      echo "present: ${relative}"
    fi
  done < "${PATCH_ROOT}/modified.tsv"
}

install_additions() {
  local expected relative source target
  while IFS=$'\t' read -r expected relative; do
    source="${PATCH_ROOT}/payload/additions/${relative}"
    target="${TARGET_ROOT}/${relative}"
    mkdir -p "$(dirname "${target}")"
    cp -p "${source}" "${target}"
    echo "added: ${relative}"
  done < "${PATCH_ROOT}/added.tsv"
}

verify_installed_tree() {
  local expected relative target actual failed=0
  while IFS=$'\t' read -r _ expected relative; do
    target="${TARGET_ROOT}/${relative}"
    actual="$(sha256_file "${target}")"
    if test "${actual}" != "${expected}"; then
      echo "FAILED: ${relative}" >&2
      failed=1
    fi
  done < "${PATCH_ROOT}/modified.tsv"
  while IFS=$'\t' read -r expected relative; do
    target="${TARGET_ROOT}/${relative}"
    if ! test -f "${target}" || test "$(sha256_file "${target}")" != "${expected}"; then
      echo "FAILED: ${relative}" >&2
      failed=1
    fi
  done < "${PATCH_ROOT}/added.tsv"
  test "${failed}" -eq 0
}

require_source_tree
validate_bundle
validate_target
apply_replacements
install_additions
verify_installed_tree

echo "FastVideo Ascend 910B Dense DMD2 bring-up patch: PASS"
